// secrets: wrangler secret put <name>
declare const publicKey: string
declare const token: string
